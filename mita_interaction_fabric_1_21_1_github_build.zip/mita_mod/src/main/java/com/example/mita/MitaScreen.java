package com.example.mita;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** A small client-side prototype. Touch zones are deliberately friendly/non-sexual. */
public class MitaScreen extends Screen {
    private int relationship = 0;
    private int dialogue = 0;
    private boolean singleHand = false;
    private String reaction = "Мита: Привет! Давай познакомимся.";
    private double mouseX, mouseY;
    private int panelX, panelY, panelW, panelH, charX, charY, charW, charH;

    private static final String[][] DIALOGUES = {
            {"Привет! Как прошёл твой день?", "Расскажи о своих увлечениях!", "Спасибо, что поговорил со мной."},
            {"Здорово, что мы общаемся чаще!", "Мне нравится наша дружба.", "Хочешь ещё поболтать?"},
            {"Я тебе доверяю. Спасибо за доброту!", "Давай продолжим разговор.", "Мне приятно проводить время вместе."}
    };
    public MitaScreen() { super(Text.literal("Мита — общение")); }

    @Override protected void init() {
        panelW = Math.min(560, width - 24); panelH = Math.min(330, height - 24);
        panelX = (width - panelW) / 2; panelY = (height - panelH) / 2;
        charW = Math.min(190, panelW / 2 - 20); charH = panelH - 90;
        charX = panelX + 24; charY = panelY + 48;
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        this.mouseX = mouseX; this.mouseY = mouseY;
        renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF0202034);
        ctx.fill(panelX, panelY, panelX + panelW, panelY + 28, 0xFFB83D83);
        ctx.drawCenteredTextWithShadow(textRenderer, "МИТА  •  знакомство и дружба", width / 2, panelY + 9, 0xFFFFFFFF);
        drawCharacter(ctx);
        int textX = charX + charW + 22;
        int textW = panelX + panelW - textX - 16;
        ctx.drawTextWrapped(textRenderer, Text.literal(reaction), textX, panelY + 50, textW, 0xFFFFD9EE);
        ctx.drawTextWithShadow(textRenderer, Text.literal("Отношения: " + relationship + "/100"), textX, panelY + 98, 0xFFFFFFFF);
        ctx.fill(textX, panelY + 113, textX + textW, panelY + 121, 0xFF4B405A);
        ctx.fill(textX, panelY + 113, textX + (textW * relationship / 100), panelY + 121, 0xFFFF79B8);
        ctx.drawTextWrapped(textRenderer, Text.literal("ЛКМ по голове, плечу или руке — дружеское взаимодействие. Уважай её границы."), textX, panelY + 132, textW, 0xFFCBC8D8);
        button(ctx, textX, panelY + 190, textW, 22, "Поговорить", 0xFF7A4BB0);
        button(ctx, textX, panelY + 218, textW, 22, singleHand ? "Режим: одна рука (H)" : "Режим: две руки (H)", 0xFF4A648F);
        ctx.drawTextWithShadow(textRenderer, Text.literal("M — открыть • H — переключить руки • Esc — выйти"), panelX + 12, panelY + panelH - 16, 0xFFBDB7CE);
        drawHands(ctx, mouseX, mouseY);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawCharacter(DrawContext ctx) {
        // Simple original placeholder avatar, built from shapes so the prototype needs no assets.
        int cx = charX + charW / 2;
        ctx.fill(charX, charY, charX + charW, charY + charH, 0xFF29283D);
        // hair and head
        ctx.fill(cx - 31, charY + 22, cx + 31, charY + 89, 0xFF6B3D70);
        ctx.fill(cx - 24, charY + 29, cx + 24, charY + 83, 0xFFFFD5C7);
        ctx.fill(cx - 27, charY + 22, cx + 26, charY + 40, 0xFF6B3D70);
        ctx.fill(cx - 24, charY + 49, cx - 16, charY + 54, 0xFF38263F);
        ctx.fill(cx + 16, charY + 49, cx + 24, charY + 54, 0xFF38263F);
        ctx.fill(cx - 7, charY + 68, cx + 7, charY + 71, 0xFFCB667D);
        // neck, shirt, arms
        ctx.fill(cx - 10, charY + 82, cx + 10, charY + 103, 0xFFFFD5C7);
        ctx.fill(cx - 43, charY + 99, cx + 43, charY + 180, 0xFFE66FA9);
        ctx.fill(cx - 59, charY + 105, cx - 39, charY + 169, 0xFFFFD5C7);
        ctx.fill(cx + 39, charY + 105, cx + 59, charY + 169, 0xFFFFD5C7);
        ctx.fill(cx - 43, charY + 180, cx + 43, charY + charH - 12, 0xFF59466D);
        ctx.drawCenteredTextWithShadow(textRenderer, "Мита", cx, charY + charH - 25, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, "Нажми ЛКМ на персонаже", cx, charY + charH + 6, 0xFFFFC5E1);
    }

    private void drawHands(DrawContext ctx, int mx, int my) {
        int y = Math.max(panelY + 34, Math.min(panelY + panelH - 35, my));
        int leftX = Math.max(panelX + 8, Math.min(panelX + panelW - 8, mx - (singleHand ? 0 : 18)));
        ctx.fill(leftX - 5, y - 5, leftX + 6, y + 6, 0xFFFF7DB8);
        if (!singleHand) {
            int rightX = Math.max(panelX + 8, Math.min(panelX + panelW - 8, mx + 18));
            ctx.fill(rightX - 4, y - 4, rightX + 5, y + 5, 0xFF7AD7FF);
        }
    }

    private void button(DrawContext ctx, int x, int y, int w, int h, String label, int color) {
        ctx.fill(x, y, x + w, y + h, color);
        ctx.drawCenteredTextWithShadow(textRenderer, label, x + w / 2, y + 7, 0xFFFFFFFF);
    }

    @Override public boolean mouseClicked(double mx, double my, int button) {
        if (button != 0) return super.mouseClicked(mx, my, button);
        int textX = charX + charW + 22;
        int textW = panelX + panelW - textX - 16;
        if (mx >= textX && mx <= textX + textW && my >= panelY + 190 && my <= panelY + 212) {
            dialogue = (dialogue + 1) % 3;
            int tier = relationship < 25 ? 0 : relationship < 65 ? 1 : 2;
            reaction = "Мита: " + DIALOGUES[tier][dialogue];
            relationship = Math.min(100, relationship + 3);
            return true;
        }
        if (mx >= charX && mx <= charX + charW && my >= charY && my <= charY + charH) {
            int localY = (int)my - charY;
            if (localY < 90) { reaction = "Мита: Спасибо за дружеское приветствие!"; relationship = Math.min(100, relationship + 2); }
            else if (localY < 180) { reaction = "Мита: Дружеское похлопывание по плечу — нормально, спасибо!"; relationship = Math.min(100, relationship + 1); }
            else { reaction = "Мита: Давай лучше поговорим. Важно уважать личные границы."; relationship = Math.max(0, relationship - 1); }
            return true;
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_H) { singleHand = !singleHand; return true; }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }
    @Override public boolean shouldPause() { return false; }
}
