# Mita Interaction — Fabric 1.21.1 prototype

This is a **client-side starter prototype**, not a finished 3D companion mod. It opens a custom interaction screen with an original placeholder avatar named Mita, dialogue, a relationship meter, cursor-following hand markers, and a one/two-hand toggle.

## Controls
- **M** — open the Mita screen
- **H** — toggle one/two hand markers
- **Left-click** the avatar's head/shoulder/other regions for friendly responses
- **Esc** — close

## Build
Requires JDK 21 and internet access for Gradle dependencies.

```bash
gradle build
```
The built jar should appear in `build/libs/`.

## Limitations
- The avatar is currently a 2D placeholder drawn with shapes, not a 3D world entity.
- The hands are UI markers that follow the cursor; they are not articulated 3D arms.
- Relationship is currently session-only and resets when the screen is recreated.
- Interactions are intentionally friendly/non-sexual and include a boundary-respecting response.
